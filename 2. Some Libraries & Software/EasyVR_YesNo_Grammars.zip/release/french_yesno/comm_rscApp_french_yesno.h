
extern far cdata gsearch_comm_french_yesno;
#ifndef NN_FRENCH_YESNO
#define NN_FRENCH_YESNO
extern far cdata nn_french_yesno;
#endif

#define G_comm_french_yesno_SILENCE                   (0)
#define G_comm_french_yesno_YES                       (1)
#define G_comm_french_yesno_NO                        (2)
#define G_comm_french_yesno_nota                      (3)

