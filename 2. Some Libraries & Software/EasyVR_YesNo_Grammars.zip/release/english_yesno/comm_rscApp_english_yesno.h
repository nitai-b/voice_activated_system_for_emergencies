
extern far cdata gsearch_comm_english_yesno;
#ifndef NN_ENGLISH_YESNO
#define NN_ENGLISH_YESNO
extern far cdata nn_english_yesno;
#endif

#define G_comm_english_yesno_SILENCE                   (0)
#define G_comm_english_yesno_YES                       (1)
#define G_comm_english_yesno_NO                        (2)
#define G_comm_english_yesno_nota                      (3)

