
extern far cdata gsearch_comm_italian_yesno;
#ifndef NN_ITALIAN_YESNO
#define NN_ITALIAN_YESNO
extern far cdata nn_italian_yesno;
#endif

#define G_comm_italian_yesno_SILENCE                   (0)
#define G_comm_italian_yesno_YES                       (1)
#define G_comm_italian_yesno_NO                        (2)
#define G_comm_italian_yesno_nota                      (3)

