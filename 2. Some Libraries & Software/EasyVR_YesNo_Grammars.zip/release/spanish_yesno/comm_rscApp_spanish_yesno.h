
extern far cdata gsearch_comm_spanish_yesno;
#ifndef NN_SPANISH_YESNO
#define NN_SPANISH_YESNO
extern far cdata nn_spanish_yesno;
#endif

#define G_comm_spanish_yesno_SILENCE                   (0)
#define G_comm_spanish_yesno_YES                       (1)
#define G_comm_spanish_yesno_NO                        (2)
#define G_comm_spanish_yesno_nota                      (3)

