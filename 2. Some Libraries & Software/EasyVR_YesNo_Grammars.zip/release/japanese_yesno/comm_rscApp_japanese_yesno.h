
extern far cdata gsearch_comm_japanese_yesno;
#ifndef NN_JAPANESE_YESNO
#define NN_JAPANESE_YESNO
extern far cdata nn_japanese_yesno;
#endif

#define G_comm_japanese_yesno_SILENCE                   (0)
#define G_comm_japanese_yesno_YES                       (1)
#define G_comm_japanese_yesno_NO                        (2)
#define G_comm_japanese_yesno_nota                      (3)

