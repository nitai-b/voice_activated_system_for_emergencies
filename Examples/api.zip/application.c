
/// THIS IS AN EXAMPLE APPLICATION THAT CAN BE LOADED BY THE BOOTLOADER
/// AND CAN USE FUNCTIONS RESIDENT IN THE FIXED BOOTLOADER AREA
///
/// ALSO SHOWN IS A NEW WAY TO RE-DIRECT RS232 I/O TO USER FUNCTIONS
/// AND A SHARED INTERRUPT

#include <18F4520.h>

#use delay(clock=20000000)

#include <api.h>

#use rs232(call_putc=api_putc, call_getc=api_getc, call_kbhit=api_kbhit)

int32 ticks=0;

#int_timer0
void timer0_isr(void) {
   ticks++;
}


void main(void) {
   int i;
   char cmd;
   
   printf("\r\nApplication program version 1.00 \r\n");

   while(TRUE) {
      printf("\r\nCount or Reload (C,R): ");
      cmd=toupper(getc());
      if(cmd=='R')
         api_load_program();
      if(cmd=='C')
         for(i=1;i<=10;i++)
            printf("%u ",++i);
   }
}

