
// This file is created by compiling 'bootloader.c'

#build(stack=28)
#build(reset=0x000500)
#build(interrupt=0x000508)
#build(interrupt_return=0x00005A)
#org 0x000000,0x000007 {}
#org 0x000008,0x00009B {}
#org 0x00009C,0x0004FF {}


extern(0x0001B0,0x0,3) void api_load_program();
extern(0x000414,0x0,2) void api_putc(int8 c);
extern(0x00041E,0x0,1) int8 api_getc();
extern(0x000428,0x0,1) int8 api_kbhit();
