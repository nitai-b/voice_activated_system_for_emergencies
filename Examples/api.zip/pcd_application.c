
/// THIS IS AN EXAMPLE APPLICATION THAT CAN BE LOADED BY THE BOOTLOADER
/// AND CAN USE FUNCTIONS RESIDENT IN THE FIXED BOOTLOADER AREA
///
/// ALSO SHOWN IS A NEW WAY TO RE-DIRECT RS232 I/O TO USER FUNCTIONS
/// AND A SHARED INTERRUPT

#include <24FJ128GA006.h>
#use delay(crystal=20mhz)

#include <pcd_api.h>

#use rs232(call_putc=api_putc, call_getc=api_getc, call_kbhit=api_kbhit)

unsigned int32 ticks=0;

#int_timer1
void timer1_isr(void) {
   ticks++;
}

unsigned int32 get_count(void)
{
   unsigned int32 result;
   
   disable_interrupts(INT_TIMER1);
   result = ticks;
   enable_interrupts(INT_TIMER1);
   
   return(result);
}

void main(void) {
   char cmd;
   
   printf("\r\n\nApplication program version 1.00 \r\n");

   while(TRUE) {
      printf("\r\nCount or Reload (C,R): ");
      cmd=toupper(getc());
      if(cmd=='R')
         api_load_program();
      if(cmd=='C')
         printf("%lu ",get_count());
   }
}

