
// This file is created by compiling 'pcd_bootloader.c'

#build(reset=0x000800)
#build(interrupt=0x000804)
#org 0x000000,0x000003 {}
#org 0x000004,0x0001FF {}
#org 0x000200,0x0007FF {}

#reserve 0x800:0x842
#reserve 0x844:0x948

extern(0x000280,0x886,1) void api_putc(int8 c);
extern(0x00028C,0x0,1) int8 api_getc();
extern(0x000294,0x0,1) int8 api_kbhit();
extern(0x0006C0,0x0,5) void api_load_program();
