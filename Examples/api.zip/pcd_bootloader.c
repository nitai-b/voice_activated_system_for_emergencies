
///  THIS PROGRAM IS A FIXED PROGRAM THAT RESIDES ALWAYS IN THE PIC TO
///  ALLOW BOOTLOADING OF THE APPLICATION AND TO PROVIDE STANDARD RESIDENT
///  FUNCTIONS TO THE APPLICATION

#include <24FJ128GA006.h>
#fuses NOWDT
#use delay(crystal=20mhz)
#use rs232(baud=9600, UART1)

#build(share_interrupts) // allows both programs to receive interrupts

#export(c,file="pcd_api.h",only="api_load_program,api_getc,api_putc,api_kbhit", \
         hexcomment="This file is created by compiling 'pcd_bootloader.c'")

///////////////////////////////////////////////////////////// BOOTLOADER
#define _bootloader

#include <pcd_bootloader.h>
#include <loader_pcd.c>

///////////////////////////////////////////////////////////// INTERRUPTS

int1 app_running=FALSE;
int32 ticks=0;

#int_timer1
void timer0_isr(void) {
   // our code here
   ticks++;   
   // now execute the applications isr
   if(app_running)
      jump_to_isr(APPLICATION_ISR_START);
}

#int_default
void default_isr(void) {
   if(app_running)
      jump_to_isr(APPLICATION_ISR_START);
}

///////////////////////////////////////////////////////////// APPLICATION INTERFACE

void api_putc(char c) {
   putc(c);
}


char api_getc(void) {
   return getc();
}


int8 api_kbhit() {
   return kbhit();
}

void api_load_program(void) {
   
   app_running = FALSE;
   
   printf("\r\n\nWaiting for File");
   
   load_program();
}

///////////////////////////////////////////////////////////// POWER UP CODE

void main(void) {
   setup_timer1(TMR_INTERNAL);
   enable_interrupts(INT_TIMER1);
   enable_interrupts(INTR_GLOBAL);

   if(!input(PIN_F6))
      api_load_program();

   app_running=TRUE;
   goto_address(APPLICATION_START); 
}
