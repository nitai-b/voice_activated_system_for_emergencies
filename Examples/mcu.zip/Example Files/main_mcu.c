
#include "project_mcu.h"

#include "report_mcu.h"
#include "filter_mcu.h"

#include <stdlib.h>
#include <input.c>

extern long report_line_number;

void main(void) {
   long data;
   
   report_line_number = 0;
   filter_clear();
   
   while( TRUE ) {
      fprintf(PC, "  Enter data point: ");
      data = get_long();
      data = filter_data(data);      
      report_data_line(data);
   }
}

