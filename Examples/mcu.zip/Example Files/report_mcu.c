

#include "project_mcu.h"

long report_line_number;


void report_data_line(int16 data){

   fprintf( PC, "%4lu  Data: %5lu\r\n", report_line_number++, data);

}

void report_error(errors error){

   switch( error ) {
     case err_range    :  fprintf( PC, "%4lu  DATA POINT OUT OF RANGE\r\n", report_line_number++);
     case err_too_far  :  fprintf( PC, "%4lu  DATA POINT TOO FAR FROM PREVIOUS POINT\r\n", report_line_number++);
     case err_too_many :  fprintf( PC, "%4lu  TOO MANY DATA POINTS\r\n", report_line_number++);
   }
}


