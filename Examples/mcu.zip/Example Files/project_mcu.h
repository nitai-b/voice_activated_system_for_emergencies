
#include <16F877A.h>
#fuses HS,NOWDT,NOPROTECT,NOLVP

#use delay(clock=20mhz)
#use rs232(BAUD=9600, UART1, STREAM=PC)

enum errors { err_range, err_too_far, err_too_many };



