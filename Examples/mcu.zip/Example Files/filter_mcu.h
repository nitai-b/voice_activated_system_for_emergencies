
void filter_clear();
long filter_data(long value);

