
void report_data_line(int16 data);
void report_error(errors error);


